import './Menu.css';

function Menu() {
  return (
    <ul className="newClass">
      <li>초밥</li>
      <li>맥모닝</li>
    </ul>
  );
}
export default Menu;
